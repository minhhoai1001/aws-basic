def my_handler(event, context):
   return "aws lambda in python using zip file"